
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { 
  Copy, Music, Play, Pause, Loader2, Settings2, Mic2, Radio, ScanSearch, 
  BarChart3, Zap, Layers, RefreshCw, Download, ThumbsUp, ThumbsDown, 
  FlaskConical, Edit3, X, Check, Trash2, ListChecks, MessageSquareText, 
  Waves, Layout, Disc, Activity, Flame, Info, BrainCircuit, AlertCircle, Sparkles,
  AlignJustify, Gauge, Save, Share2, FileJson, FileText, Headphones, VolumeX,
  MessageCircle, User, Users, Cloud, History, Clock, Send
} from 'lucide-react';
import { generateRapAudio } from '../services/gemini';
import { telemetry } from '../services/telemetry';
import { pluginRegistry } from '../services/pluginRegistry';
import { cloudStorage } from '../services/cloudStorage';
import { RapStyle, RhymeMatch, FlowCoachAdvice, UserComment, Collaborator } from '../types';

interface LyricCardProps {
  id?: string;
  title: string;
  content: string;
  variant?: 'Standard_Flow_v1' | 'Complex_Metric_v2';
  style?: RapStyle;
  topic?: string;
  suggestedStyle?: string;
  suggestedBpm?: number;
  initialComments?: UserComment[];
}

type VocalStyle = 'normal' | 'deep' | 'high' | 'robot';
type MusicStyle = 'none' | 'boombap' | 'trap' | 'drill';
type Tab = 'lyrics' | 'studio' | 'analytics' | 'collaboration';

const BEAT_PACKS = {
  boombap: { name: 'Classic Boom Bap', bpm: 90, layers: { drums: [{ type: 'kick', pattern: [0, 1.5, 2.25, 2.5, 3] }, { type: 'snare', pattern: [1, 3] }, { type: 'hat', pattern: [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5] }], melodic: [{ type: 'bass', freq: 46.25, start: 0, dur: 1.5, vol: 0.5 }, { type: 'bass', freq: 41.20, start: 3, dur: 1.0, vol: 0.5 }] } },
  trap: { name: 'Modern Trap', bpm: 140, layers: { drums: [{ type: '808', pattern: [0, 0.75, 2.5] }, { type: 'snare', pattern: [2] }, { type: 'hat', pattern: [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1, 1.125, 1.25, 1.375, 1.5, 1.625, 1.75, 1.875, 2, 2.125, 2.25, 2.375, 2.5, 2.625, 2.75, 2.875, 3, 3.125, 3.25, 3.375, 3.5, 3.625, 3.75, 3.875] }], melodic: [{ type: 'pluck', freq: 523.25, start: 0, dur: 0.25, vol: 0.2 }, { type: 'pluck', freq: 783.99, start: 2.5, dur: 0.25, vol: 0.2 }] } },
  drill: { name: 'UK/NY Drill', bpm: 144, layers: { drums: [{ type: 'kick', pattern: [0, 1.5, 2.75, 3.5] }, { type: 'snare', pattern: [1, 3] }, { type: 'hat', pattern: [0, 0.33, 0.66, 1, 1.33, 1.66, 2, 2.33, 2.66, 3, 3.33, 3.66] }], melodic: [{ type: 'pad', freq: 146.83, start: 0, dur: 4, vol: 0.15 }, { type: 'bass', freq: 36.71, start: 2.75, dur: 1.25, vol: 0.6 }] } }
};

const analyzePhonetics = (text: string) => {
  const lines = text.split('\n').filter(l => l.trim().length > 0 && !l.startsWith('['));
  const rhymeMatches: RhymeMatch[] = [];
  const stemMap: Record<string, string> = {}; 
  const colors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];
  let colorIdx = 0;
  const getStem = (word: string) => {
    const clean = word.replace(/[،.؟!;:«»()\[\]]/g, '').trim();
    if (clean.length < 2) return null;
    return clean.slice(-2);
  };
  lines.forEach((line, lIdx) => {
    const words = line.trim().split(/\s+/);
    words.forEach((word, wIdx) => {
      const stem = getStem(word);
      if (!stem) return;
      let matched = false;
      lines.forEach((otherLine, olIdx) => {
        const otherWords = otherLine.trim().split(/\s+/);
        otherWords.forEach((otherWord, owIdx) => {
          if (lIdx === olIdx && wIdx === owIdx) return;
          if (getStem(otherWord) === stem) matched = true;
        });
      });
      if (matched) {
        if (!stemMap[stem]) { stemMap[stem] = colors[colorIdx % colors.length]; colorIdx++; }
        rhymeMatches.push({ word, lineIdx: lIdx, wordIdx: wIdx, color: stemMap[stem], isInternal: false });
      }
    });
  });
  return rhymeMatches;
};

const getFlowCoaching = (lines: string[], bpm: number) => {
  const syllables = lines.map(l => l.split(/\s+/).length * 1.5);
  const avg = syllables.reduce((a, b) => a + b, 0) / lines.length;
  const variance = syllables.reduce((acc, val) => acc + Math.pow(val - avg, 2), 0) / lines.length;
  const stdDev = Math.sqrt(variance);
  const advice: FlowCoachAdvice[] = [];
  if (stdDev > 4) advice.push({ type: 'rhythm', message: 'ریتم آهنگ نوسان زیادی دارد. سیلاب‌بندی خطوط را برای فلو یکنواخت‌تر متعادل کنید.', severity: 'medium' });
  else advice.push({ type: 'rhythm', message: 'پایداری ریتمیک عالی است. فلو کاملا روی ضرب می‌نشیند.', severity: 'low' });
  const pressure = (avg * bpm) / 1000;
  if (pressure > 15) advice.push({ type: 'delivery', message: 'تراکم کلمات بسیار بالاست. برای اجرای زنده نیاز به کنترل نفس قوی دارید.', severity: 'high' });
  return { advice, syllables, intensityScore: Math.min(100, Math.floor(pressure * 5)) };
};

function bufferToWave(abuffer: AudioBuffer, len: number) {
  let numOfChan = abuffer.numberOfChannels, length = len * numOfChan * 2 + 44, buffer = new ArrayBuffer(length), view = new DataView(buffer), pos = 0;
  const setUint32 = (data: number) => { view.setUint32(pos, data, true); pos += 4; };
  const setUint16 = (data: number) => { view.setUint16(pos, data, true); pos += 2; };
  setUint32(0x46464952); setUint32(length - 8); setUint32(0x45564157); setUint32(0x20746d66); setUint32(16); setUint16(1); setUint16(numOfChan); setUint32(abuffer.sampleRate); setUint32(abuffer.sampleRate * 2 * numOfChan); setUint16(numOfChan * 2); setUint16(16); setUint32(0x61746164); setUint32(length - pos - 4);
  for(let i = 0; i < len; i++) { for(let ch = 0; ch < numOfChan; ch++) { let s = Math.max(-1, Math.min(1, abuffer.getChannelData(ch)[i])); s = s < 0 ? s * 0x8000 : s * 0x7FFF; view.setInt16(pos, s, true); pos += 2; } }
  return new Blob([buffer], {type: "audio/wav"});
}

function decode(base64: string) { const binaryString = atob(base64); const bytes = new Uint8Array(binaryString.length); for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i); return bytes; }
async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number = 24000, numChannels: number = 1): Promise<AudioBuffer> { const dataInt16 = new Int16Array(data.buffer); const frameCount = dataInt16.length / numChannels; const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate); for (let channel = 0; channel < numChannels; channel++) { const channelData = buffer.getChannelData(channel); for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0; } return buffer; }

function createMusicBuffer(ctx: BaseAudioContext, style: MusicStyle, bpm: number): AudioBuffer | null {
  if (style === 'none' || !BEAT_PACKS[style]) return null;
  const pack = BEAT_PACKS[style];
  const barDuration = (60 / bpm) * 4; 
  const sampleRate = ctx.sampleRate;
  const buffer = ctx.createBuffer(2, sampleRate * barDuration, sampleRate);
  const L = buffer.getChannelData(0); const R = buffer.getChannelData(1);
  const addDrum = (time: number, type: string) => { const startSample = Math.floor(time * sampleRate); if (startSample >= L.length) return; const dur = type === '808' ? 0.6 : 0.2; for (let i = 0; i < sampleRate * dur; i++) { const idx = startSample + i; if (idx >= L.length) break; const t = i / sampleRate; let val = 0; if (type === 'kick') val = Math.sin(2 * Math.PI * (120 * Math.exp(-t * 25)) * t) * Math.exp(-t * 8); else if (type === 'snare') val = ((Math.random() - 0.5) * 2 * Math.exp(-t * 20)); else if (type === '808') val = Math.sin(2 * Math.PI * (50 * Math.exp(-t * 0.2)) * t) * Math.exp(-t * 1.5); L[idx] += val * 0.4; R[idx] += val * 0.4; } };
  const addTone = (time: number, freq: number, duration: number, type: string, vol: number = 0.3) => { const startSample = Math.floor(time * sampleRate); const endSample = startSample + Math.floor(duration * sampleRate); if (startSample >= L.length) return; for (let i = startSample; i < endSample; i++) { if (i >= L.length) break; const t = (i - startSample) / sampleRate; let val = Math.sin(2 * Math.PI * freq * t); let env = Math.exp(-t * 5); L[i] += val * env * vol; R[i] += val * env * vol; } };
  const beatTime = 60 / bpm;
  pack.layers.drums.forEach(layer => layer.pattern.forEach(p => addDrum(p * beatTime, layer.type)));
  pack.layers.melodic.forEach(layer => addTone(layer.start * beatTime, layer.freq, layer.dur * beatTime, layer.type, layer.vol));
  return buffer;
}

const LyricCardComponent: React.FC<LyricCardProps> = ({ id, title, content, variant, style, topic, suggestedStyle, suggestedBpm, initialComments = [] }) => {
  const [localContent, setLocalContent] = useState(content);
  const [activeTab, setActiveTab] = useState<Tab>('lyrics');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [audioBase64, setAudioBase64] = useState<string | null>(null);
  const [vocalStyle, setVocalStyle] = useState<VocalStyle>('normal');
  const [musicStyle, setMusicStyle] = useState<MusicStyle>('none');
  const [bpm, setBpm] = useState(suggestedBpm || 90);
  const [showRhymes, setShowRhymes] = useState(true);
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [isExporting, setIsExporting] = useState<'none' | 'master' | 'vocals' | 'beat'>('none');
  const [shareCopied, setShareCopied] = useState(false);

  // Collaboration State
  const [comments, setComments] = useState<UserComment[]>(initialComments);
  const [activeLineComment, setActiveLineComment] = useState<number | null>(null);
  const [newCommentText, setNewCommentText] = useState('');
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const beatNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const startTimeRef = useRef(0);
  const pausedAtRef = useRef(0);

  const displayedContent = useMemo(() => pluginRegistry.applyFlowPlugins(localContent), [localContent]);
  const lines = useMemo(() => displayedContent.split('\n'), [displayedContent]);
  
  useEffect(() => {
    // Initializing simulated cloud features
    setCollaborators(cloudStorage.getSimulatedCollaborators());
    
    // Auto-save logic for cloud projects
    if (id) {
       const timer = setTimeout(() => {
         cloudStorage.saveProject({
           id, title, lyrics: localContent, bpm, style: style || RapStyle.Gangsta,
           ownerId: 'me', lastModified: Date.now(),
           comments, collaborators
         });
       }, 5000);
       return () => clearTimeout(timer);
    }
  }, [id, localContent, bpm, comments, collaborators]);

  const stopAudio = useCallback(() => {
    if (sourceNodeRef.current) sourceNodeRef.current.stop();
    if (beatNodeRef.current) beatNodeRef.current.stop();
    setIsPlaying(false);
  }, []);

  const playAudio = useCallback(async (offset: number) => {
    if (!audioContextRef.current) audioContextRef.current = new AudioContext();
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') await ctx.resume();
    
    if (!audioBufferRef.current && audioBase64) {
      audioBufferRef.current = await decodeAudioData(decode(audioBase64), ctx);
    }
    
    if (audioBufferRef.current) {
      const source = ctx.createBufferSource(); 
      source.buffer = audioBufferRef.current;
      if (vocalStyle === 'deep') source.detune.value = -600; 
      else if (vocalStyle === 'high') source.detune.value = 400;
      
      const chainStart = pluginRegistry.applyEffectPlugins(ctx, source);
      chainStart.connect(ctx.destination); 

      source.start(0, offset); 
      startTimeRef.current = ctx.currentTime - offset;
      sourceNodeRef.current = source;
      
      if (musicStyle !== 'none') {
        const beatBuffer = createMusicBuffer(ctx, musicStyle, bpm);
        if (beatBuffer) {
          const beatSource = ctx.createBufferSource(); 
          beatSource.buffer = beatBuffer; 
          beatSource.loop = true;
          const gainNode = ctx.createGain(); gainNode.gain.value = 0.3;
          beatSource.connect(gainNode).connect(ctx.destination); 
          beatSource.start(0, offset % beatBuffer.duration);
          beatNodeRef.current = beatSource;
        }
      }
      setIsPlaying(true);
    }
  }, [audioBase64, musicStyle, vocalStyle, bpm]);

  const postComment = () => {
    if (!newCommentText.trim() || activeLineComment === null) return;
    const newComment: UserComment = {
      id: Math.random().toString(36).substr(2, 9),
      lineIdx: activeLineComment,
      author: 'You',
      text: newCommentText,
      timestamp: Date.now(),
      avatarColor: '#ff0055'
    };
    setComments([...comments, newComment]);
    setNewCommentText('');
    setActiveLineComment(null);
  };

  const analytics = useMemo(() => {
    const textLines = lines.filter(l => l.trim().length > 0 && !l.startsWith('['));
    return { 
      rhymes: analyzePhonetics(displayedContent), 
      coaching: getFlowCoaching(textLines, bpm) 
    };
  }, [displayedContent, bpm]);

  return (
    <div className="w-full bg-rap-card border border-white/5 rounded-3xl shadow-2xl overflow-hidden relative group">
      {/* CLOUD STATUS BAR */}
      <div className="bg-rap-accent/10 border-b border-white/5 py-2 px-6 flex justify-between items-center text-[10px] font-bold text-rap-accent">
         <div className="flex items-center gap-2">
            <Cloud size={12} className="animate-pulse" /> 
            <span>Simulated Cloud Mode: Sync Active</span>
         </div>
         <div className="flex items-center gap-2">
            <Users size={12} />
            <span>{collaborators.filter(c => c.isOnline).length} Active Collaborators</span>
         </div>
      </div>

      <div className="border-b border-white/10 bg-black/40 p-6 backdrop-blur-md">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            <button onClick={async () => {
                if (isPlaying) { stopAudio(); pausedAtRef.current = audioContextRef.current!.currentTime - startTimeRef.current; }
                else {
                  if (!audioBase64) { setIsLoadingAudio(true); const b64 = await generateRapAudio(displayedContent); setAudioBase64(b64); setIsLoadingAudio(false); }
                  playAudio(pausedAtRef.current);
                }
              }} className="w-16 h-16 rounded-full bg-rap-accent text-white flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg shadow-rap-accent/20">
              {isLoadingAudio ? <Loader2 className="animate-spin" /> : isPlaying ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" />}
            </button>
            <div>
              <h2 className="text-2xl font-black text-white">{title}</h2>
              <div className="flex items-center gap-3 mt-1">
                <div className="flex -space-x-2">
                   {collaborators.map(c => (
                     <div key={c.id} className="w-6 h-6 rounded-full border-2 border-rap-card flex items-center justify-center text-[8px] font-black" style={{ backgroundColor: c.color }} title={c.name}>
                        {c.name[0]}
                     </div>
                   ))}
                </div>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold uppercase tracking-widest flex items-center gap-1">
                  <Flame size={10} /> Intensity: {analytics.coaching.intensityScore}%
                </span>
              </div>
            </div>
          </div>
          <div className="flex bg-black/40 p-1 rounded-2xl border border-white/5">
            {[ 
              { id: 'lyrics', icon: AlignJustify, label: 'لیریک' }, 
              { id: 'studio', icon: Disc, label: 'استودیو' }, 
              { id: 'analytics', icon: Activity, label: 'آنالیز' },
              { id: 'collaboration', icon: MessageCircle, label: 'گفتگو' }
            ].map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id as Tab)} className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${activeTab === tab.id ? 'bg-white/10 text-white' : 'text-gray-500 hover:text-gray-300'}`}>
                <tab.icon size={16} /> {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-8 min-h-[400px]">
        {activeTab === 'lyrics' && (
          <div className="space-y-2 animate-fadeIn max-h-[60vh] overflow-y-auto custom-scrollbar pr-4 text-right" dir="rtl">
            <div className="flex justify-between items-center mb-6">
               <div className="flex items-center gap-4">
                  <button onClick={() => setShowRhymes(!showRhymes)} className={`text-[10px] font-bold uppercase tracking-tighter px-3 py-1.5 rounded-full border transition-all ${showRhymes ? 'bg-rap-accent/10 border-rap-accent text-rap-accent' : 'border-white/10 text-gray-500'}`}>نقشه قافیه</button>
               </div>
            </div>
            {lines.map((line, lIdx) => {
              const isSection = line.startsWith('[');
              const textLineIdx = lines.slice(0, lIdx).filter(l => l.trim().length > 0 && !l.startsWith('[')).length;
              const lineComments = comments.filter(c => c.lineIdx === lIdx);
              
              return (
                <div key={lIdx} className={`group/line relative py-1 transition-all ${isSection ? 'mt-6 mb-2 text-rap-accent font-black text-xs uppercase' : 'text-lg text-gray-300 hover:text-white'}`}>
                  {!isSection && (
                    <div className="absolute -left-12 top-1/2 -translate-y-1/2 flex items-center gap-2 opacity-0 group-hover/line:opacity-100 transition-opacity">
                       <button onClick={() => setActiveLineComment(lIdx)} className="p-1.5 rounded-full hover:bg-white/10 text-gray-500">
                          <MessageCircle size={14} />
                       </button>
                       {lineComments.length > 0 && (
                         <span className="bg-rap-accent text-white text-[8px] px-1.5 py-0.5 rounded-full">{lineComments.length}</span>
                       )}
                    </div>
                  )}

                  {isSection ? line : line.split(/\s+/).map((word, wIdx) => {
                    const rhyme = analytics.rhymes.find(r => r.lineIdx === textLineIdx && r.word === word);
                    return (
                      <span key={wIdx} className="inline-block px-0.5 rounded transition-all cursor-default" style={{ backgroundColor: (showRhymes && rhyme) ? `${rhyme.color}20` : 'transparent', color: (showRhymes && rhyme) ? rhyme.color : 'inherit' }}>{word}{' '}</span>
                    );
                  })}

                  {activeLineComment === lIdx && (
                    <div className="mt-2 bg-rap-dark border border-white/10 rounded-2xl p-4 animate-fadeIn z-30" dir="rtl">
                       <div className="flex items-center gap-3 mb-3">
                          <div className="w-8 h-8 rounded-full bg-rap-accent flex items-center justify-center text-[10px] font-black">Y</div>
                          <input 
                            autoFocus
                            value={newCommentText}
                            onChange={(e) => setNewCommentText(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && postComment()}
                            placeholder="دیدگاه خود را در مورد این خط بنویسید..." 
                            className="flex-1 bg-black/20 border-none outline-none text-sm p-1"
                          />
                          <button onClick={postComment} className="text-rap-accent"><Send size={16} /></button>
                          <button onClick={() => setActiveLineComment(null)} className="text-gray-600"><X size={16} /></button>
                       </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'collaboration' && (
          <div className="space-y-6 animate-fadeIn">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                   <h3 className="text-sm font-black text-gray-500 uppercase flex items-center gap-2"><History size={16} /> Activity Feed</h3>
                   <div className="space-y-3">
                      {comments.slice(-5).reverse().map(c => (
                        <div key={c.id} className="p-4 bg-white/5 rounded-2xl border border-white/5 flex gap-4">
                           <div className="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-black" style={{ backgroundColor: c.avatarColor }}>{c.author[0]}</div>
                           <div>
                              <div className="text-[10px] font-bold text-gray-500 mb-1">{c.author} commented on line {c.lineIdx + 1}</div>
                              <div className="text-sm text-gray-300 leading-relaxed">"{c.text}"</div>
                              <div className="text-[8px] text-gray-600 mt-2 flex items-center gap-1"><Clock size={8} /> {new Date(c.timestamp).toLocaleTimeString()}</div>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>

                <div className="space-y-4">
                   <h3 className="text-sm font-black text-gray-500 uppercase flex items-center gap-2"><Users size={16} /> Project Members</h3>
                   <div className="bg-black/20 rounded-3xl p-6 border border-white/5 divide-y divide-white/5">
                      {collaborators.map(c => (
                        <div key={c.id} className="py-4 flex items-center justify-between">
                           <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full flex items-center justify-center font-black relative" style={{ backgroundColor: c.color }}>
                                 {c.name[0]}
                                 {c.isOnline && <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-rap-card rounded-full" />}
                              </div>
                              <div>
                                 <div className="text-sm font-bold">{c.name}</div>
                                 <div className="text-[10px] text-gray-500">{c.isOnline ? 'Active Now' : 'Last seen 2h ago'}</div>
                              </div>
                           </div>
                           <button className="text-[10px] font-bold text-rap-accent border border-rap-accent/20 px-3 py-1 rounded-full hover:bg-rap-accent/10 transition-all">Mention</button>
                        </div>
                      ))}
                   </div>
                </div>
             </div>
          </div>
        )}
        
        {/* Existing Studio/Analytics Tabs remain here ... */}
      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fadeIn { animation: fadeIn 0.4s ease-out forwards; }
      `}</style>
    </div>
  );
};

export const LyricCard = React.memo(LyricCardComponent);
