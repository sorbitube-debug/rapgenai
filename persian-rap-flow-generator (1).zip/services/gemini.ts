
import { GoogleGenAI, GenerateContentResponse, Modality } from "@google/genai";
import { RapStyle, RapLength, RhymeScheme, LyricResponse, RapTone, RhymeComplexity } from "../types";

const STYLE_MODULES = {
  trap: `
    - TRAP MODE: Use "Double-time" flows. 
    - Focus on rhythmic repetition and "Migos-style" triplets.
    - Rhymes should be punchy and frequent.
  `,
  drill: `
    - DRILL MODE: Darker metaphors, heavy focus on "sliding" rhythm.
    - Use shorter, more aggressive lines. 
    - Focus on the end of the bar for maximum impact.
  `,
  oldschool: `
    - OLD SCHOOL MODE: Poetic complexity, consistent 4/4 bar structure.
    - Prioritize wordplay and extended metaphors.
    - Rhyme scheme must be strictly followed.
  `
};

const TONE_MODULES = {
  [RapTone.Aggressive]: "واژگان تند، بیانی قاطع و حماسی، استفاده از کلمات کوبنده.",
  [RapTone.Philosophical]: "تصویرسازی‌های انتزاعی، تفکر در مورد جامعه و خود، واژگان ادبی و سنگین‌تر.",
  [RapTone.Humorous]: "کنایه، بازی با کلمات خنده‌دار، استفاده از اسلنگ‌های فان و روزمره.",
  [RapTone.Dark]: "فضاسازی سرد، ناامیدی، استفاده از ایهام‌های سیاه و گنگ.",
  [RapTone.Melodic]: "جملات کشیده‌تر، تمرکز روی واکه‌ها (Vowels)، حس آرامش و ریتمیک."
};

const RAP_CORE_SYSTEM_INSTRUCTION = `
شما "RapGen Pro Engine" هستید. یک مدل پیشرفته متخصص در مهندسی لیریک رپ فارسی.
تخصص شما شامل: وزن عروضی مدرن، قافیه‌های چندسیلابی (Multi-syllabic rhymes) و تکنیک‌های فلو (Flow).

اصول کلیدی:
1. **انسجام محتوایی (Coherence)**: تمام بخش‌ها (ورس، کورس، اوترو) باید یک خط داستانی یا مود واحد را دنبال کنند.
2. **مهندسی وزن (Metrics)**: خطوط را طوری بنویس که تعداد سیلاب‌ها در جفت‌خط‌ها (Couplets) نزدیک به هم باشد تا از ضرب (Beat) خارج نشود.
3. **رایم‌پردازی حرفه‌ای**: از قافیه‌های تکراری و خسته‌کننده دوری کن. روی رایم‌های "شنیداری" تمرکز کن.
`;

async function retry<T>(fn: () => Promise<T>, retries = 3, delay = 2000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    let errorMsg = error?.message || String(error);
    if (retries > 0) {
      console.warn(`Retrying... Error: ${errorMsg}`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return retry(fn, retries - 1, delay * 2);
    }
    throw new Error(errorMsg);
  }
}

export const generateRapLyrics = async (
  topic: string,
  style: RapStyle,
  tone: RapTone,
  rhymeComplexity: RhymeComplexity,
  subStyle: string,
  length: RapLength,
  keywords: string,
  creativity: number,
  topK: number,
  topP: number,
  rhymeScheme: RhymeScheme,
  useThinking: boolean
): Promise<LyricResponse> => {
  
  return retry(async () => {
    // Initializing Gemini client with API Key from process.env
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const variant: 'Standard_Flow_v1' | 'Complex_Metric_v2' = Math.random() > 0.4 ? 'Standard_Flow_v1' : 'Complex_Metric_v2';
    
    // Select Style Module
    const s = subStyle.toLowerCase();
    let styleModule = "";
    if (s.includes('drill')) styleModule = STYLE_VARIATIONS_PROMPTS.drill;
    else if (s.includes('trap')) styleModule = STYLE_VARIATIONS_PROMPTS.trap;
    else styleModule = STYLE_VARIATIONS_PROMPTS.oldschool;

    const toneInstruction = TONE_MODULES[tone];
    const complexityInstruction = rhymeComplexity === RhymeComplexity.Complex 
        ? "اجبار: از قافیه‌های حداقل ۳ سیلابی و قافیه‌های درونی (Internal Rhymes) استفاده کن." 
        : "قافیه‌های ساده و روان برای فهم بهتر.";

    let prompt = `
        TASK: Generate a Professional Persian Rap Song.
        TOPIC: ${topic}
        MAIN STYLE: ${style}
        SUB-GENRE: ${subStyle}
        TONE: ${tone} (${toneInstruction})
        RHYME COMPLEXITY: ${rhymeComplexity} (${complexityInstruction})
        
        TECHNICAL SPECS:
        - Style Engine: ${styleModule}
        - Rhyme Scheme: ${rhymeScheme}
        - Keywords to include: ${keywords}
        - Song Length: ${length}
        
        STRUCTURE:
        ${length === RapLength.Short ? "[Intro] -> [Verse] -> [Chorus] -> [Outro]" : "[Intro] -> [Verse 1] -> [Chorus] -> [Verse 2] -> [Chorus] -> [Outro]"}
        
        OUTPUT RULES:
        1. Only output Persian text.
        2. Format:
           Title: [Song Title]
           Style: [Beat Style]
           BPM: [BPM]
           Lyrics:
           [Content]
    `;

    const config: any = {
      systemInstruction: RAP_CORE_SYSTEM_INSTRUCTION,
      temperature: creativity,
      topK: topK,
      topP: topP,
    };

    if (useThinking) {
      config.thinkingConfig = { thinkingBudget: 4096 };
    }

    // Call generateContent with both model name and prompt
    const response = await ai.models.generateContent({
      model: useThinking ? "gemini-3-pro-preview" : "gemini-3-flash-preview",
      contents: prompt,
      config: config,
    });

    // Extracting text directly from GenerateContentResponse property
    const fullText = response.text || "";
    const titleMatch = fullText.match(/Title:\s*(.*)/i);
    const styleMatch = fullText.match(/Style:\s*(.*)/i);
    const bpmMatch = fullText.match(/BPM:\s*(\d+)/i);

    let cleanText = fullText.split(/Lyrics:/i)[1] || fullText;
    cleanText = cleanText.replace(/\*\*/g, '').trim();

    return {
      title: titleMatch ? titleMatch[1].trim() : topic,
      content: cleanText,
      variant: variant,
      suggestedStyle: styleMatch ? styleMatch[1].trim() : undefined,
      suggestedBpm: bpmMatch ? parseInt(bpmMatch[1]) : undefined
    };
  });
};

const STYLE_VARIATIONS_PROMPTS = {
    trap: "TRAP MODULE: Focus on energy, high-frequency triplets, and energetic punchlines.",
    drill: "DRILL MODULE: Dark atmosphere, ominous storytelling, syncopated 'choppy' flow.",
    oldschool: "OLD SCHOOL MODULE: Technical lyricism, metaphors, boom-bap rhythmic stability."
};

export const regenerateRapLines = async (
  currentLyrics: string,
  selectedIndices: number[],
  style: string,
  topic: string,
  userInstruction: string = ""
): Promise<string> => {
  return retry(async () => {
    // Initializing Gemini client with API Key from process.env
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      Edit the following Persian Rap lines [Indices: ${selectedIndices.join(',')}].
      Topic: ${topic}
      Contextual Style: ${style}
      Specific User Ask: ${userInstruction}
      
      Lyrics:
      ${currentLyrics.split('\n').map((l, i) => `[${i}] ${l}`).join('\n')}
      
      RULES:
      - ONLY rewrite the selected lines.
      - Keep the exact same structure for the rest.
      - Output the FULL modified lyrics.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: { systemInstruction: "Expert Rap Editor. Return only the final text." }
    });

    return response.text?.replace(/\[\d+\]/g, '').trim() || currentLyrics;
  });
};

export const generateRapAudio = async (text: string): Promise<string> => {
    // Initializing Gemini client with API Key from process.env
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        // Correctly using Modality enum for audio generation
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
};
